from setuptools import setup

setup(name='dsnd_probs',
      version='0.1',
      description='Gaussian distributions',
      packages=['dsnd_probs'],
      author = 'Soro Kolotioloma',
      author_email = 'ksoro17@alustudent.com',
      zip_safe=False)
